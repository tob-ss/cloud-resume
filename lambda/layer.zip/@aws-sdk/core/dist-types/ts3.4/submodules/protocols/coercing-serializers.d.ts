export declare const _toStr: (val: unknown) => string | undefined;
export declare const _toBool: (val: unknown) => boolean | undefined;
export declare const _toNum: (val: unknown) => number | undefined;
