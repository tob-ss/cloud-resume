export declare const awsExpectUnion: (
  value: unknown
) => Record<string, any> | undefined;
