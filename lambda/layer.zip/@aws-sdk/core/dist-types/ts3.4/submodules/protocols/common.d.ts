import { SerdeContext } from "@smithy/types";
export declare const collectBodyString: (
  streamBody: any,
  context: SerdeContext
) => Promise<string>;
