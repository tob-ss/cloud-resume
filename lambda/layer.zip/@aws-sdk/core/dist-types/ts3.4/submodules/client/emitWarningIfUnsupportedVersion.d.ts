export declare const state: {
  warningEmitted: boolean;
};
export declare const emitWarningIfUnsupportedVersion: (version: string) => void;
